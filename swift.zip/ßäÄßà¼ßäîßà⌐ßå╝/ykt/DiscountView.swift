//
//  DiscountView.swift
//  ykt
//
//  Created by mac17 on 10/27/25.
//

import SwiftUI

struct DiscountView: View {
    var body: some View {
        Text("할인정보뷰")
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    DiscountView()
}
