//
//  yktApp.swift
//  ykt
//
//  Created by mac17 on 10/27/25.
//

import SwiftUI

@main
struct yktApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()

        }
    }
}
